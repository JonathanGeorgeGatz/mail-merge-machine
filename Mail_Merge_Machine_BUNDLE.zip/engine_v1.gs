/** EP17 first build (v1) — REAL defects, kept verbatim for the episode:
 *  1. The only verb is send. It loops the Contacts rows and calls GmailApp.sendEmail on every
 *     one, immediately. No preview, no drafts, no log of any kind.
 *  2. Placeholders are matched against headers EXACTLY — case, spacing and all. The template
 *     says {{First Name}}; the sheet's header is "First name"; every letter ships with the
 *     hole still in it.
 *  3. Raw values. getValues() hands back Date objects and numbers; v1 string-concatenates
 *     them, so a letter reads "...last serviced on Fri Nov 14 2025 00:00:00 GMT+0000
 *     (Coordinated Universal Time)".
 *  4. No validation, no dedupe, no opt-out — and no try/catch. The first address Gmail
 *     rejects kills the run mid-list, and the only record of who already got a letter is
 *     the mailbox's own Sent folder.
 */
function v1_runMerge(input, gmail) {
  var headers = input.headers;
  var col = {};
  for (var h = 0; h < headers.length; h++) col[String(headers[h])] = h; // EXACT keys
  var emailCol = col['Email'];
  var fill = function (text, row) {
    return String(text).replace(/\{\{([^{}]*)\}\}/g, function (whole, name) {
      var ci = col[name];                       // exact match or nothing
      if (ci === undefined) return whole;       // leave the hole in
      return '' + row[ci];                      // raw: Dates and floats as-is
    });
  };
  var sent = 0;
  for (var r = 0; r < input.rows.length; r++) {
    var row = input.rows[r];
    var to = '' + row[emailCol];
    // no validation, no dedupe, no opt-out, no try/catch:
    gmail.sendEmail(to, fill(input.template.subject, row), fill(input.template.body, row));
    sent++;
  }
  return { sent: sent };
}
if (typeof module !== 'undefined') module.exports = { v1_runMerge: v1_runMerge };
