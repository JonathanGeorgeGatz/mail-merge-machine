/** EP17 second build (v2) — prompt 2 applied (preview first, drafts not sends, headers matched
 *  like a person reads them, dates and numbers written out), with THREE remaining defects the
 *  independent checker caught:
 *  1. Duplicate detection compares the raw address string — "D.Fairbanks@Example.com" and
 *     "d.fairbanks@example.com" read as two different people, and one of them is drafted twice.
 *  2. An empty merge field substitutes an empty string, silently. The letter opens "Dear ,".
 *  3. A row whose email is blank or fails v2's own validation is silently skipped: no draft,
 *     no log line, no count. The list goes in 52 rows long and comes out shorter, and nothing
 *     on the page says why. (v2 also ignores the Opt Out column entirely — nobody asked it to.)
 */
var V2_MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August',
                 'September', 'October', 'November', 'December'];
function v2_norm(v) {
  if (v instanceof Date) return V2_MONTHS[v.getMonth()] + ' ' + v.getDate() + ', ' + v.getFullYear();
  if (typeof v === 'number') return Number.isInteger(v) ? String(v) : v.toFixed(2);
  return String(v == null ? '' : v);
}
function v2_runMerge(input) {
  var headers = input.headers;
  var col = {};
  for (var h = 0; h < headers.length; h++) {
    var k = String(headers[h]).trim().replace(/\s+/g, ' ').toLowerCase();
    if (!(k in col)) col[k] = h;
  }
  var emailCol = col['email'];
  var seen = {}; // RAW string -> true   (the bug)
  var letters = [];
  for (var r = 0; r < input.rows.length; r++) {
    var row = input.rows[r];
    var email = v2_norm(row[emailCol]).trim();
    if (email === '' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) continue; // silent skip
    if (seen[email]) continue; // raw-string dedupe: a case variant walks right past this
    seen[email] = true;
    var fill = function (text) {
      return String(text).replace(/\{\{([^{}]*)\}\}/g, function (_, name) {
        var ci = col[String(name).trim().replace(/\s+/g, ' ').toLowerCase()];
        if (ci === undefined) return ''; // and unknown fields vanish silently too
        return v2_norm(row[ci]).trim();  // empty cell -> '' -> "Dear ,"
      });
    };
    letters.push({ row: r + 2, email: email, subject: fill(input.template.subject), body: fill(input.template.body) });
  }
  return { letters: letters, drafted: letters.length };
}
if (typeof module !== 'undefined') module.exports = { v2_runMerge: v2_runMerge };
