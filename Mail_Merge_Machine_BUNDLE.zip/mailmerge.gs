/** The Mail Merge Machine — final engine (EP17 "Build It With AI").
 * Pure core: computeMerge(input, settings). Google Sheets + Gmail wrapper at the bottom.
 * input = { headers: [...], rows: [[...]], template: { subject, body } }   (strings only — the
 * wrapper normalizes Dates and numbers before the core ever sees them)
 * settings = { mode:'drafts'|'send', quota:100, optOutColumn:'Opt Out', alsoRequire:'' }
 *
 * It drafts. Sending is a separate, conscious mode behind the quota math. It never guesses.
 */

var EMAIL_RE = /^[A-Za-z0-9._%+'-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$/;

function normKey(s) {
  return String(s == null ? '' : s).trim().replace(/\s+/g, ' ').toLowerCase();
}
function normEmail(s) {
  return String(s == null ? '' : s).trim().toLowerCase();
}
function halfUpDiv(a, b) { return Math.floor((2 * a + b) / (2 * b)); }
function fmtPctTenths(t) { return Math.floor(t / 10) + '.' + (t % 10); }

/** Collect {{placeholders}} in order of first appearance (subject first, then body). */
function placeholdersOf(template) {
  var out = [], seen = {};
  var re = /\{\{([^{}]*)\}\}/g, m;
  var texts = [template.subject || '', template.body || ''];
  for (var i = 0; i < texts.length; i++) {
    re.lastIndex = 0;
    while ((m = re.exec(texts[i])) !== null) {
      var name = m[1].trim();
      var key = normKey(name);
      if (!seen[key]) { seen[key] = true; out.push({ name: name, key: key }); }
    }
  }
  return out;
}

function computeMerge(input, settings) {
  var S = {
    mode: (settings && settings.mode) === 'send' ? 'send' : 'drafts',
    quota: settings && settings.quota != null ? settings.quota : 100,
    optOutColumn: settings && settings.optOutColumn != null ? settings.optOutColumn : 'Opt Out',
    alsoRequire: settings && settings.alsoRequire != null ? settings.alsoRequire : ''
  };
  var headers = input.headers, rows = input.rows;
  var colByKey = {};
  for (var h = 0; h < headers.length; h++) {
    var k = normKey(headers[h]);
    if (!(k in colByKey)) colByKey[k] = h;
  }

  // ---- config refusals (the run stops) ----
  var config = [];
  var emailCol = colByKey['email'];
  if (emailCol === undefined) config.push('the list has no Email column');
  var ph = placeholdersOf(input.template);
  for (var p = 0; p < ph.length; p++) {
    if (colByKey[ph[p].key] === undefined)
      config.push('the letter references {{' + ph[p].name + '}} but the list has no such column');
  }
  var optCol = -1;
  if (normKey(S.optOutColumn) !== '') {
    if (colByKey[normKey(S.optOutColumn)] === undefined)
      config.push('the opt-out column "' + String(S.optOutColumn).trim() + '" is not in the list');
    else optCol = colByKey[normKey(S.optOutColumn)];
  }
  var alsoNames = String(S.alsoRequire).split(',').map(function (s) { return s.trim(); }).filter(function (s) { return s !== ''; });
  for (var a = 0; a < alsoNames.length; a++) {
    if (colByKey[normKey(alsoNames[a])] === undefined)
      config.push('the required column "' + alsoNames[a] + '" is not in the list');
  }
  if (config.length) {
    return {
      settings: S,
      counts: { contacts: rows.length, merged: 0, skipped: 0, refused: 0, drafted: 0, sent: 0, held: 0 },
      letters: [], skipped: [], refused: [], config: config,
      recon: { rowsTie: false, holes: 0, dupOk: true, quotaOk: true, refusedPctTenths: 0,
               trusted: false, banner: 'DO NOT TRUST THIS MERGE — ' + config[0] }
    };
  }

  // required columns: template fields (minus Email) in first-appearance order, then alsoRequire
  var required = [], reqSeen = {};
  for (p = 0; p < ph.length; p++) {
    if (ph[p].key === 'email') continue;
    if (!reqSeen[ph[p].key]) { reqSeen[ph[p].key] = true; required.push(ph[p].key); }
  }
  for (a = 0; a < alsoNames.length; a++) {
    var ak = normKey(alsoNames[a]);
    if (!reqSeen[ak]) { reqSeen[ak] = true; required.push(ak); }
  }
  var headerByKey = {};
  for (h = 0; h < headers.length; h++) {
    k = normKey(headers[h]);
    if (!(k in headerByKey)) headerByKey[k] = String(headers[h]).trim();
  }

  // ---- row classification ----
  var letters = [], skippedL = [], refused = [];
  var seenEmail = {}; // normEmail -> keeper sheet row
  for (var r = 0; r < rows.length; r++) {
    var row = rows[r];
    var sheetRow = r + 2;
    var cell = function (ci) { return String(row[ci] == null ? '' : row[ci]).trim(); };
    var email = cell(emailCol);
    if (email === '') { refused.push({ row: sheetRow, email: '', reason: 'no email address' }); continue; }
    if (!EMAIL_RE.test(email)) {
      refused.push({ row: sheetRow, email: email, reason: 'doesn’t look like an email address: "' + email + '"' });
      continue;
    }
    var ne = normEmail(email);
    if (seenEmail[ne] !== undefined) {
      refused.push({ row: sheetRow, email: email, reason: 'duplicate of row ' + seenEmail[ne] + ' — the first row was kept' });
      continue;
    }
    seenEmail[ne] = sheetRow;
    if (optCol >= 0) {
      var ov = cell(optCol);
      var ovl = ov.toLowerCase();
      if (ovl !== '' && ovl !== 'no') {
        skippedL.push({ row: sheetRow, email: email, value: ov });
        continue;
      }
    }
    var emptyField = null;
    for (var q = 0; q < required.length; q++) {
      if (cell(colByKey[required[q]]) === '') { emptyField = headerByKey[required[q]]; break; }
    }
    if (emptyField !== null) {
      refused.push({ row: sheetRow, email: email, reason: 'required field "' + emptyField + '" is empty — the letter would go out with a hole' });
      continue;
    }
    var fill = function (text) {
      return String(text).replace(/\{\{([^{}]*)\}\}/g, function (_, name) {
        return cell(colByKey[normKey(name)]);
      });
    };
    letters.push({ row: sheetRow, email: email, subject: fill(input.template.subject || ''), body: fill(input.template.body || '') });
  }

  // ---- actions ----
  var sent = 0, drafted = 0, held = 0;
  for (var L = 0; L < letters.length; L++) {
    if (S.mode === 'send') {
      if (sent < S.quota) { letters[L].action = 'SEND'; sent++; }
      else { letters[L].action = 'HOLD'; letters[L].reason = 'today’s quota of ' + S.quota + ' is spent — held for tomorrow'; held++; }
    } else { letters[L].action = 'DRAFT'; drafted++; }
  }

  var counts = { contacts: rows.length, merged: letters.length, skipped: skippedL.length,
                 refused: refused.length, drafted: drafted, sent: sent, held: held };
  var rowsTie = counts.contacts === counts.merged + counts.skipped + counts.refused;
  var holes = 0, dupCheck = {}, dupOk = true;
  for (L = 0; L < letters.length; L++) {
    if (letters[L].subject.indexOf('{{') >= 0 || letters[L].body.indexOf('{{') >= 0) holes++;
    var dk = normEmail(letters[L].email);
    if (dupCheck[dk]) dupOk = false;
    dupCheck[dk] = true;
  }
  var quotaOk = sent <= S.quota;
  var pctT = counts.contacts ? halfUpDiv(counts.refused * 1000, counts.contacts) : 0;
  var trusted = rowsTie && holes === 0 && dupOk && quotaOk && pctT <= 100;
  var banner = '';
  if (!trusted) {
    banner = 'DO NOT TRUST THIS MERGE — ' + (!rowsTie ? 'the row buckets do not tie.'
      : holes > 0 ? 'a letter still has an unfilled placeholder.'
      : !dupOk ? 'two letters share an address.'
      : !quotaOk ? 'more sends than today’s quota.'
      : 'too many rows refused (' + fmtPctTenths(pctT) + '%). Fix the list and run it again.');
  }
  return { settings: S, counts: counts, letters: letters, skipped: skippedL, refused: refused,
           config: [],
           recon: { rowsTie: rowsTie, holes: holes, dupOk: dupOk, quotaOk: quotaOk,
                    refusedPctTenths: pctT, trusted: trusted, banner: banner } };
}

/* ---------------- Google Sheets + Gmail wrapper ---------------- */

var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August',
              'September', 'October', 'November', 'December'];

/** Sheets hands back Dates and numbers; letters want words. One documented rule. */
function normalizeCell(v) {
  if (v instanceof Date) return MONTHS[v.getMonth()] + ' ' + v.getDate() + ', ' + v.getFullYear();
  if (typeof v === 'number') return Number.isInteger(v) ? String(v) : v.toFixed(2);
  return String(v == null ? '' : v);
}

function buildMerge() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  function sheet(name) {
    var sh = ss.getSheetByName(name);
    if (!sh) throw new Error('Missing tab: ' + name);
    return sh.getDataRange().getValues();
  }
  var cv = sheet('Contacts').filter(function (r) { return r.join('').trim() !== ''; });
  var headers = cv[0].map(normalizeCell);
  var rows = cv.slice(1).map(function (r) { return r.map(normalizeCell); });

  var template = { subject: '', body: '' };
  sheet('Letter').forEach(function (r) {
    var k = normKey(r[0]);
    if (k === 'subject') template.subject = String(r[1] == null ? '' : r[1]);
    if (k === 'body') template.body = String(r[1] == null ? '' : r[1]);
  });

  var st = { mode: 'drafts', quota: 100, optOutColumn: 'Opt Out', alsoRequire: '' };
  var reviewed = '';
  var settingsSh = ss.getSheetByName('Settings');
  if (settingsSh) {
    settingsSh.getDataRange().getValues().forEach(function (r) {
      var k = String(r[0]).trim(), v = r[1];
      if (k === 'Mode') st.mode = String(v).trim() === 'send' ? 'send' : 'drafts';
      if (k === 'Daily send budget') st.quota = Number(v);
      if (k === 'Opt-out column') st.optOutColumn = String(v == null ? '' : v).trim();
      if (k === 'Also require (columns)') st.alsoRequire = String(v == null ? '' : v);
      if (k === 'I reviewed the Preview') reviewed = String(v == null ? '' : v).trim().toLowerCase();
    });
  }
  var downgraded = false;
  if (st.mode === 'send' && reviewed !== 'yes') { st.mode = 'drafts'; downgraded = true; }
  if (st.mode === 'send') {
    // Google's own meter outranks the Settings cell: never start more than today allows.
    var remaining = MailApp.getRemainingDailyQuota();
    if (remaining < st.quota) st.quota = remaining;
  }

  var res = computeMerge({ headers: headers, rows: rows, template: template }, st);

  // ---- act on the plan ----
  res.letters.forEach(function (L) {
    if (L.action === 'DRAFT') GmailApp.createDraft(L.email, L.subject, L.body);
    else if (L.action === 'SEND') GmailApp.sendEmail(L.email, L.subject, L.body);
    // HOLD: logged, never touched
  });

  // ---- Preview tab ----
  var pv = ss.getSheetByName('Preview') || ss.insertSheet('Preview');
  pv.clear();
  var prows = [['THE MAIL MERGE MACHINE — preview (read these before anything is sent)', '', '']];
  prows.push([res.recon.trusted
    ? 'Reconciliation ties — ' + res.counts.contacts + ' rows = ' + res.counts.merged + ' letters + '
      + res.counts.skipped + ' opted out + ' + res.counts.refused + ' refused'
    : res.recon.banner, '', '']);
  if (downgraded) prows.push(['Send mode was requested but "I reviewed the Preview" is not "yes" — ran as drafts instead.', '', '']);
  prows.push(['Row', 'To / Subject', 'Letter']);
  res.letters.forEach(function (L) {
    prows.push([L.row, L.email + '  —  ' + L.subject, L.body]);
  });
  pv.getRange(1, 1, prows.length, 3).setValues(prows);

  // ---- Merge Log tab ----
  var lg = ss.getSheetByName('Merge Log') || ss.insertSheet('Merge Log');
  lg.clear();
  var lrows = [[res.recon.trusted ? 'MERGE LOG — every row accounted for' : res.recon.banner, '', '']];
  lrows.push([res.counts.contacts + ' rows = ' + res.counts.merged + ' letters + ' + res.counts.skipped
    + ' opted out + ' + res.counts.refused + ' refused', '', '']);
  lrows.push(['Mode: ' + st.mode + ' · drafted ' + res.counts.drafted + ' · sent ' + res.counts.sent
    + ' · held ' + res.counts.held + ' · today’s budget ' + st.quota, '', '']);
  lrows.push(['Row', 'Outcome', 'Detail']);
  res.letters.forEach(function (L) {
    lrows.push([L.row, L.action === 'DRAFT' ? 'DRAFTED' : L.action === 'SEND' ? 'SENT' : 'HELD',
                L.email + (L.reason ? ' — ' + L.reason : '')]);
  });
  res.skipped.forEach(function (s) { lrows.push([s.row, 'SKIPPED', s.email + ' — asked not to be emailed ("' + s.value + '")']); });
  res.refused.forEach(function (rf) { lrows.push([rf.row, 'REFUSED', (rf.email ? rf.email + ' — ' : '') + rf.reason]); });
  res.config.forEach(function (c) { lrows.push(['—', 'CONFIG', c]); });
  lg.getRange(1, 1, lrows.length, 3).setValues(lrows);
  return res;
}

if (typeof module !== 'undefined') module.exports = {
  computeMerge: computeMerge, normKey: normKey, normEmail: normEmail,
  placeholdersOf: placeholdersOf, normalizeCell: normalizeCell, EMAIL_RE: EMAIL_RE
};
