#!/usr/bin/env python3
"""EP17 independent checker — a second implementation of the Mail Merge Machine spec (SPEC.md),
written in Python, sharing no code with the shipped .gs engine. Reads an input JSON on stdin
({headers, rows, template, settings}) and prints the full report JSON on stdout. Every output
string (reasons, banner) must match the engine byte for byte."""
import json
import re
import sys

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+'-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$")
PH_RE = re.compile(r"\{\{([^{}]*)\}\}")


def norm_key(s):
    return re.sub(r"\s+", " ", ("" if s is None else str(s)).strip()).lower()


def norm_email(s):
    return ("" if s is None else str(s)).strip().lower()


def half_up_div(a, b):
    return (2 * a + b) // (2 * b)


def fmt_pct_tenths(t):
    return f"{t // 10}.{t % 10}"


def placeholders_of(template):
    out, seen = [], set()
    for text in (template.get("subject") or "", template.get("body") or ""):
        for m in PH_RE.finditer(text):
            name = m.group(1).strip()
            key = norm_key(name)
            if key not in seen:
                seen.add(key)
                out.append((name, key))
    return out


def compute(inp):
    st_in = inp.get("settings") or {}
    S = {
        "mode": "send" if st_in.get("mode") == "send" else "drafts",
        "quota": st_in.get("quota", 100),
        "optOutColumn": st_in.get("optOutColumn", "Opt Out"),
        "alsoRequire": st_in.get("alsoRequire", ""),
    }
    headers, rows = inp["headers"], inp["rows"]
    col_by_key = {}
    for i, h in enumerate(headers):
        k = norm_key(h)
        if k not in col_by_key:
            col_by_key[k] = i

    config = []
    email_col = col_by_key.get("email")
    if email_col is None:
        config.append("the list has no Email column")
    ph = placeholders_of(inp["template"])
    for name, key in ph:
        if key not in col_by_key:
            config.append("the letter references {{" + name + "}} but the list has no such column")
    opt_col = -1
    if norm_key(S["optOutColumn"]) != "":
        k = norm_key(S["optOutColumn"])
        if k not in col_by_key:
            config.append('the opt-out column "' + str(S["optOutColumn"]).strip() + '" is not in the list')
        else:
            opt_col = col_by_key[k]
    also_names = [s.strip() for s in str(S["alsoRequire"]).split(",") if s.strip() != ""]
    for n in also_names:
        if norm_key(n) not in col_by_key:
            config.append('the required column "' + n + '" is not in the list')
    if config:
        return {
            "settings": S,
            "counts": {"contacts": len(rows), "merged": 0, "skipped": 0, "refused": 0,
                       "drafted": 0, "sent": 0, "held": 0},
            "letters": [], "skipped": [], "refused": [], "config": config,
            "recon": {"rowsTie": False, "holes": 0, "dupOk": True, "quotaOk": True,
                      "refusedPctTenths": 0, "trusted": False,
                      "banner": "DO NOT TRUST THIS MERGE — " + config[0]},
        }

    required, req_seen = [], set()
    for name, key in ph:
        if key == "email" or key in req_seen:
            continue
        req_seen.add(key)
        required.append(key)
    for n in also_names:
        k = norm_key(n)
        if k not in req_seen:
            req_seen.add(k)
            required.append(k)
    header_by_key = {}
    for h in headers:
        k = norm_key(h)
        if k not in header_by_key:
            header_by_key[k] = str(h).strip()

    letters, skipped_l, refused = [], [], []
    seen_email = {}
    for r, row in enumerate(rows):
        sheet_row = r + 2

        def cell(ci):
            v = row[ci] if ci < len(row) else ""
            return ("" if v is None else str(v)).strip()

        email = cell(email_col)
        if email == "":
            refused.append({"row": sheet_row, "email": "", "reason": "no email address"})
            continue
        if not EMAIL_RE.match(email):
            refused.append({"row": sheet_row, "email": email,
                            "reason": 'doesn’t look like an email address: "' + email + '"'})
            continue
        ne = norm_email(email)
        if ne in seen_email:
            refused.append({"row": sheet_row, "email": email,
                            "reason": "duplicate of row " + str(seen_email[ne]) + " — the first row was kept"})
            continue
        seen_email[ne] = sheet_row
        if opt_col >= 0:
            ov = cell(opt_col)
            if ov.lower() not in ("", "no"):
                skipped_l.append({"row": sheet_row, "email": email, "value": ov})
                continue
        empty_field = None
        for key in required:
            if cell(col_by_key[key]) == "":
                empty_field = header_by_key[key]
                break
        if empty_field is not None:
            refused.append({"row": sheet_row, "email": email,
                            "reason": 'required field "' + empty_field + '" is empty — the letter would go out with a hole'})
            continue

        def fill(text):
            return PH_RE.sub(lambda m: cell(col_by_key[norm_key(m.group(1))]), str(text))

        letters.append({"row": sheet_row, "email": email,
                        "subject": fill(inp["template"].get("subject") or ""),
                        "body": fill(inp["template"].get("body") or "")})

    sent = drafted = held = 0
    for L in letters:
        if S["mode"] == "send":
            if sent < S["quota"]:
                L["action"] = "SEND"
                sent += 1
            else:
                L["action"] = "HOLD"
                L["reason"] = "today’s quota of " + str(S["quota"]) + " is spent — held for tomorrow"
                held += 1
        else:
            L["action"] = "DRAFT"
            drafted += 1

    counts = {"contacts": len(rows), "merged": len(letters), "skipped": len(skipped_l),
              "refused": len(refused), "drafted": drafted, "sent": sent, "held": held}
    rows_tie = counts["contacts"] == counts["merged"] + counts["skipped"] + counts["refused"]
    holes = sum(1 for L in letters if "{{" in L["subject"] or "{{" in L["body"])
    dup_seen, dup_ok = set(), True
    for L in letters:
        dk = norm_email(L["email"])
        if dk in dup_seen:
            dup_ok = False
        dup_seen.add(dk)
    quota_ok = sent <= S["quota"]
    pct_t = half_up_div(counts["refused"] * 1000, counts["contacts"]) if counts["contacts"] else 0
    trusted = rows_tie and holes == 0 and dup_ok and quota_ok and pct_t <= 100
    banner = ""
    if not trusted:
        if not rows_tie:
            why = "the row buckets do not tie."
        elif holes > 0:
            why = "a letter still has an unfilled placeholder."
        elif not dup_ok:
            why = "two letters share an address."
        elif not quota_ok:
            why = "more sends than today’s quota."
        else:
            why = "too many rows refused (" + fmt_pct_tenths(pct_t) + "%). Fix the list and run it again."
        banner = "DO NOT TRUST THIS MERGE — " + why
    return {"settings": S, "counts": counts, "letters": letters, "skipped": skipped_l,
            "refused": refused, "config": [],
            "recon": {"rowsTie": rows_tie, "holes": holes, "dupOk": dup_ok, "quotaOk": quota_ok,
                      "refusedPctTenths": pct_t, "trusted": trusted, "banner": banner}}


if __name__ == "__main__":
    print(json.dumps(compute(json.load(sys.stdin))))
